# Tamweel Lite | مشروعك النهائي

## الملخص التنفيذي
تم اختيار نموذج الانحدار اللوجستي لمشروع Tamweel Lite التعليمي، حيث حقق أعلى متوسط لمقياس الدقة المتوسطة (AP) بقيمة 0.39166، دون أن تحقق النماذج التجميعية تحسنًا يبرر تعقيدها. حققت عتبة القرار 0.168922 خسارة تعليمية بلغت 1,111 وحدة مع الالتزام بسقف المراجعة البالغ 12%. وبعد المعايرة، نُقلت العتبة إلى 0.122258 دون تحسن في مؤشرات موثوقية الاحتمالات. ومن أصل 2,500 طلب ضمن بيانات التحدي، تم تحديد 330 طلبًا مؤهلًا للمراجعة واستبعاد 30 طلبًا وفقًا لقيد السعة، ليصبح العدد النهائي 300 طلب (12%). تقتصر النتائج على الاستخدام التعليمي، ولا تمثل ضمانًا للأداء المستقبلي أو شهادة للعدالة، ولا يجوز استخدامها لاتخاذ قرارات تمويل فعلية.

## Executive summary
Logistic Regression was selected as the final Tamweel Lite model, achieving the highest mean AP of 0.39166 without sufficient improvement from ensembles to justify their complexity. The raw threshold of 0.168922 achieved an educational loss of 1,111 units while satisfying the 12% review capacity ceiling. Sigmoid calibration transported the threshold to 0.122258 but did not improve the reported reliability metrics. Of 2,500 challenge applications, 330 were initially eligible and 30 were removed by capacity, leaving 300 final flags (12%). These results are strictly educational and do not establish independent challenge performance, future generalization, or fairness certification.

Decision: KEEP SINGLE / Logistic. Full-batch flags: 300/2500.

اقرأ reports/MODEL_CARD.md والسياسة في artifacts/final_policy.json. الحزمة للتدريب؛ ليست نتيجة تقييم نهائية أو إثبات تسليم. ادمج أدلة أيامك السابقة واحفظ الدفتر المنفذ والعرض.
